test output <?php echo $foo; ?>
